#!/usr/bin/env python3
"""
apply_gimmick_to_item.py — patch any iteminfo item to dock a chosen gimmick.

Two modes:

  --mode minimal   (default)
    Only swaps `gimmick_info` and `docking_child_data.gimmick_info_key` to the
    target gimmick. Leaves attach_parent_socket_name, docking_tag_name_hash,
    and the rest of docking_child_data alone. Cheapest test — works only if
    the gimmick mesh/VFX doesn't care which named socket it attaches to.

  --mode full
    Also overwrites attach_parent_socket_name and is_item_equip_docking_gimmick
    to mirror the source wrapper (1001062). Use if --mode minimal shows nothing
    in-game. Risk: target item may not expose the source's socket bone, in
    which case the gimmick still won't render.

Usage:
  python tools/apply_gimmick_to_item.py
  python tools/apply_gimmick_to_item.py --item 1003265 --gimmick 1001961
  python tools/apply_gimmick_to_item.py --mode full
  python tools/apply_gimmick_to_item.py --input-iteminfo "C:/path/existing/mod/iteminfo.pabgb"
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

import crimson_rs


DEFAULT_GAME_PATH = r"C:\Program Files (x86)\Steam\steamapps\common\Crimson Desert"
DEFAULT_ITEM_KEY = 1003265        # GreyWolf_OneHandBow
DEFAULT_GIMMICK_KEY = 1001961     # Sealed_Abyss_Artifact_0033 (lightning imbue)
DEFAULT_SOURCE_WRAPPER = 1001062  # Marni_MachineKnight_TwoHandSword (known-working wrapper)


def patch_item(items: list, item_key: int, gimmick_key: int,
               source_key: int | None, mode: str) -> dict:
    by_key = {it.get("key"): it for it in items}
    target = by_key.get(item_key)
    if target is None:
        raise SystemExit(f"item key={item_key} not found")
    if "docking_child_data" not in target or target.get("docking_child_data") is None:
        raise SystemExit(
            f"item {item_key} has no docking_child_data field — can't dock a gimmick to it. "
            "Pick an item that already has its own gimmick (so the slot exists)."
        )

    before_gimmick = target.get("gimmick_info")
    before_dcd = dict(target["docking_child_data"])

    target["gimmick_info"] = gimmick_key
    target["docking_child_data"]["gimmick_info_key"] = gimmick_key

    if mode == "full":
        if source_key is None:
            raise SystemExit("--mode full requires --source-wrapper")
        src = by_key.get(source_key)
        if src is None or src.get("docking_child_data") is None:
            raise SystemExit(f"source wrapper {source_key} not found / has no docking_child_data")
        src_dcd = src["docking_child_data"]
        for k in ("attach_parent_socket_name", "is_item_equip_docking_gimmick"):
            if k in src_dcd:
                target["docking_child_data"][k] = src_dcd[k]

    return {
        "item_key": item_key,
        "string_key": target.get("string_key"),
        "before": {"gimmick_info": before_gimmick, "docking_child_data": before_dcd},
        "after":  {"gimmick_info": target["gimmick_info"],
                   "docking_child_data": dict(target["docking_child_data"])},
        "mode": mode,
    }


def write_mod_folder(out_dir: Path, iteminfo_bytes: bytes, mod_name: str,
                     diff: dict) -> None:
    if out_dir.exists():
        import shutil
        shutil.rmtree(out_dir)
    files_dir = out_dir / "files" / "gamedata" / "binary__" / "client" / "bin"
    files_dir.mkdir(parents=True, exist_ok=True)
    (files_dir / "iteminfo.pabgb").write_bytes(iteminfo_bytes)

    modinfo = {
        "id": mod_name.lower().replace(" ", "_"),
        "name": mod_name,
        "version": "0.1.0",
        "game_version": "1.00.03",
        "author": "apply_gimmick_to_item",
        "description": (
            f"Docks gimmick {diff['after']['gimmick_info']} onto item "
            f"{diff['item_key']} ({diff['string_key']}), mode={diff['mode']}."
        ),
    }
    (out_dir / "modinfo.json").write_text(
        json.dumps(modinfo, indent=2), encoding="utf-8"
    )

    # Also drop the diff for reference
    (out_dir / "patch_diff.json").write_text(
        json.dumps(diff, indent=2, default=str), encoding="utf-8"
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Dock a gimmick onto any iteminfo item.")
    p.add_argument("--game-path", default=DEFAULT_GAME_PATH)
    p.add_argument("--input-iteminfo", default=None,
                   help="path to existing iteminfo.pabgb (preserves your other iteminfo mod's changes)")
    p.add_argument("--item", type=int, default=DEFAULT_ITEM_KEY,
                   help=f"target item key (default {DEFAULT_ITEM_KEY} = GreyWolf_OneHandBow)")
    p.add_argument("--gimmick", type=int, default=DEFAULT_GIMMICK_KEY,
                   help=f"gimmick info key (default {DEFAULT_GIMMICK_KEY} = lightning imbue)")
    p.add_argument("--mode", choices=("minimal", "full", "passive-only"), default="minimal",
                   help="minimal = swap gimmick keys only; full = also clone socket name; "
                        "passive-only = skip gimmick swap entirely (use with --add-passive)")
    p.add_argument("--source-wrapper", type=int, default=DEFAULT_SOURCE_WRAPPER,
                   help=f"item to clone socket from (--mode full only). Default {DEFAULT_SOURCE_WRAPPER}")
    p.add_argument("--add-passive", type=int, nargs=2, metavar=("SKILL_ID", "LEVEL"),
                   default=None,
                   help="add a passive skill {skill:N, level:M} to the target item's "
                        "equip_passive_skill_list. e.g. --add-passive 91101 3 for the "
                        "lightning imbue passive shared by all lightning weapons.")
    p.add_argument("--out", default="gimmick_test_mod")
    p.add_argument("--mod-name", default="Lightning Gimmick on Bow (Test)")
    args = p.parse_args()

    if args.input_iteminfo:
        src_path = Path(args.input_iteminfo).resolve()
        if not src_path.is_file():
            raise SystemExit(f"--input-iteminfo not found: {src_path}")
        print(f"=> Reading existing iteminfo from: {src_path}")
        raw = src_path.read_bytes()
        print(f"   size: {len(raw):,} bytes  (layered on top of your mod)")
    else:
        print(f"=> Extracting vanilla iteminfo from: {args.game_path}")
        raw = crimson_rs.extract_file(
            args.game_path, "0008", "gamedata/binary__/client/bin", "iteminfo.pabgb"
        )
        print(f"   size: {len(raw):,} bytes  (vanilla)")

    items = crimson_rs.parse_iteminfo_from_bytes(raw)
    print(f"   parsed items: {len(items):,}")

    if args.mode == "passive-only":
        # Skip gimmick patch entirely. Build a stub diff so the rest of the
        # pipeline still has metadata for the mod folder.
        target = next((it for it in items if it.get("key") == args.item), None)
        if target is None:
            raise SystemExit(f"item key={args.item} not found")
        print(f"\n=> mode=passive-only — skipping gimmick swap on item {args.item}")
        diff = {
            "item_key": args.item,
            "string_key": target.get("string_key"),
            "before": {"gimmick_info": target.get("gimmick_info"),
                       "docking_child_data": target.get("docking_child_data")},
            "after":  {"gimmick_info": target.get("gimmick_info"),
                       "docking_child_data": target.get("docking_child_data")},
            "mode": args.mode,
        }
    else:
        print(f"\n=> Patching item {args.item} -> gimmick {args.gimmick} (mode={args.mode})")
        diff = patch_item(items, args.item, args.gimmick, args.source_wrapper, args.mode)

    if args.add_passive:
        skill_id, level = args.add_passive
        target = next(it for it in items if it.get("key") == args.item)
        psl = target.get("equip_passive_skill_list") or []
        if not any(s.get("skill") == skill_id for s in psl):
            psl.append({"skill": skill_id, "level": level})
            target["equip_passive_skill_list"] = psl
            print(f"   +passive: skill={skill_id} level={level}  (now {psl})")
        else:
            print(f"   passive {skill_id} already present on item — left as-is")
    print(f"   string_key: {diff['string_key']}")
    print(f"   gimmick_info: {diff['before']['gimmick_info']} -> {diff['after']['gimmick_info']}")
    print(f"   docking_child_data BEFORE:\n      {json.dumps(diff['before']['docking_child_data'], default=str)[:200]}")
    print(f"   docking_child_data AFTER:\n      {json.dumps(diff['after']['docking_child_data'], default=str)[:200]}")

    print("\n=> Re-serializing iteminfo...")
    new_bytes = bytes(crimson_rs.serialize_iteminfo(items))
    print(f"   new size: {len(new_bytes):,} bytes  (delta {len(new_bytes) - len(raw):+d})")

    out_dir = Path(args.out).resolve()
    print(f"\n=> Writing mod folder: {out_dir}")
    write_mod_folder(out_dir, new_bytes, args.mod_name, diff)
    print(f"   wrote files/gamedata/binary__/client/bin/iteminfo.pabgb")
    print(f"   wrote modinfo.json + patch_diff.json")

    print("\n=> Done. Install via your mod loader, equip the target item, watch for the gimmick.")
    print("   If --mode minimal shows nothing, re-run with --mode full.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
