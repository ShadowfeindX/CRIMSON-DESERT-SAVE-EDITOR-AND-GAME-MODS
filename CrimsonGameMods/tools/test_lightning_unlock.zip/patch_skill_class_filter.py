#!/usr/bin/env python3
"""
patch_skill_class_filter.py — Potter's approach for opening up a passive
skill's allowed-equip-type-class list, applied to the Grey Wolf Bow case.

Potter's reference patch (skill 91109 Equip_Passive_Bismuth_Spear):
  offsetFromName: 107
  OLD: 01 00 00 00 EC 7B BE AD          (count=1, 1 hash entry)
  NEW: 02 00 00 00 20 4E 61 BC E9 FF C9 40   (count=2, 2 hash entries)

This script applies the same pattern to skill 91101 (Equip_Passive_Lightning,
shared by every lightning weapon). It:

  1. Extracts skill.pabgb from group 0008.
  2. Locates a target skill record by NAME string (default tries lightning
     candidate strings).
  3. Reads the count + hash list at NAME_OFFSET + 107 bytes (Potter's offset).
  4. Appends one or more equip_type_info hashes (default: Grey Wolf Bow's
     equip_type_info = 249090674) and bumps the count.
  5. Writes the modified skill.pabgb into a CDUMM-compatible mod folder.

Usage:
  python tools/patch_skill_class_filter.py                       # auto-discover lightning skill names
  python tools/patch_skill_class_filter.py --dry-run             # show what's at +107 without writing
  python tools/patch_skill_class_filter.py --skill-name Equip_Passive_Lightning
  python tools/patch_skill_class_filter.py --add-hash 249090674  # explicitly Grey Wolf Bow
  python tools/patch_skill_class_filter.py --offset 107 --add-hash 249090674

If skill.pabgb is loaded as a file-overlay by your mod loader (same way
iteminfo.pabgb is), no PAZ checksum work is needed. If your loader requires
PAZ packing for skill.pabgb specifically, this script does NOT do that — it
only emits the modified raw .pabgb file.

Drop the resulting mod folder into your loader's mods directory and equip
the Grey Wolf Bow (or whatever item carries the target skill).
"""
from __future__ import annotations
import argparse
import json
import struct
import sys
from pathlib import Path

import crimson_rs

DEFAULT_GAME_PATH = r"C:\Program Files (x86)\Steam\steamapps\common\Crimson Desert"

# Strings to search for (in order). Stop at the first one found in skill.pabgb.
# Skill 91101 is the imbue-lightning passive shared by every lightning weapon.
DEFAULT_SKILL_NAME_CANDIDATES = [
    "Equip_Passive_Lightning",
    "Equip_Passive_Lightning_Sword",
    "Equip_Passive_Lightning_Spear",
    "Equip_Passive_Imbue_Lightning",
]

DEFAULT_OFFSET_FROM_NAME = 107            # Potter's value
DEFAULT_HASH_TO_ADD      = 249090674      # Grey Wolf Bow's equip_type_info


def find_name_offset(blob: bytes, name: str) -> int:
    """Locate the C-string in the pabgb. Returns offset of the first byte of
    the name, or -1 if not found."""
    needle = name.encode("ascii") + b"\x00"
    idx = blob.find(needle)
    return idx


def read_class_list(blob: bytes, name_off: int, offset_from_name: int) -> tuple[int, list[int], int]:
    """Read the count u32 and the count*u32 hashes following NAME_OFF + OFFSET.

    Returns (count, hashes, list_position_in_blob).
    """
    pos = name_off + offset_from_name
    count = struct.unpack_from("<I", blob, pos)[0]
    if count > 64:  # sanity — class lists shouldn't be huge
        raise SystemExit(
            f"sanity check failed: count={count} at pos=0x{pos:X} looks bogus. "
            "Either the offset is wrong for this skill record, or the format is "
            "different. Try --dry-run with --hexdump to inspect."
        )
    hashes = list(struct.unpack_from(f"<{count}I", blob, pos + 4))
    return count, hashes, pos


def patch_class_list(blob: bytes, list_pos: int, count: int, old_hashes: list[int],
                     new_hashes: list[int]) -> bytes:
    """Splice the count + hashes at list_pos, lengthening or shrinking the file
    as needed."""
    old_block_len = 4 + 4 * count
    new_count = count + len(new_hashes)
    new_block = struct.pack("<I", new_count) + struct.pack(f"<{len(old_hashes + new_hashes)}I", *(old_hashes + new_hashes))
    return blob[:list_pos] + new_block + blob[list_pos + old_block_len:]


def write_mod_folder(out_dir: Path, skill_pabgb: bytes, mod_name: str, diff: dict) -> None:
    if out_dir.exists():
        import shutil
        shutil.rmtree(out_dir)
    files_dir = out_dir / "files" / "gamedata" / "binary__" / "client" / "bin"
    files_dir.mkdir(parents=True, exist_ok=True)
    (files_dir / "skill.pabgb").write_bytes(skill_pabgb)

    modinfo = {
        "id": mod_name.lower().replace(" ", "_"),
        "name": mod_name,
        "version": "0.1.0",
        "game_version": "1.00.03",
        "author": "patch_skill_class_filter",
        "description": (
            f"Adds equip_type hash(es) {diff['added_hashes']} to the allowed-class "
            f"list of skill record matching name {diff['name']!r} at "
            f"offset+{diff['offset_from_name']}."
        ),
    }
    (out_dir / "modinfo.json").write_text(json.dumps(modinfo, indent=2), encoding="utf-8")
    (out_dir / "patch_diff.json").write_text(json.dumps(diff, indent=2), encoding="utf-8")


def hexdump(blob: bytes, start: int, length: int = 64) -> str:
    chunk = blob[start:start + length]
    out = []
    for i in range(0, len(chunk), 16):
        row = chunk[i:i + 16]
        hex_str = " ".join(f"{b:02X}" for b in row)
        ascii_str = "".join(chr(b) if 32 <= b < 127 else "." for b in row)
        out.append(f"  {start + i:08X}  {hex_str:<47}  {ascii_str}")
    return "\n".join(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.strip().splitlines()[0])
    p.add_argument("--game-path", default=DEFAULT_GAME_PATH)
    p.add_argument("--skill-name", default=None,
                   help="exact C-string of the target skill record. If omitted, "
                        "tries DEFAULT_SKILL_NAME_CANDIDATES in order.")
    p.add_argument("--offset", type=int, default=DEFAULT_OFFSET_FROM_NAME,
                   help=f"byte offset from start of name to count+hash list "
                        f"(default {DEFAULT_OFFSET_FROM_NAME}, Potter's value)")
    p.add_argument("--add-hash", type=int, nargs="+", default=[DEFAULT_HASH_TO_ADD],
                   help="equip_type_info hash(es) to append. "
                        f"default {DEFAULT_HASH_TO_ADD} (GreyWolf_OneHandBow)")
    p.add_argument("--dry-run", action="store_true",
                   help="show current count + hashes; do not write anything")
    p.add_argument("--hexdump", action="store_true",
                   help="with --dry-run, also dump 64 bytes around the list position")
    p.add_argument("--out", default="lightning_skill_unlock_test")
    p.add_argument("--mod-name", default="Lightning Skill: add bow class (test)")
    args = p.parse_args()

    print(f"=> Extracting skill.pabgb from: {args.game_path}")
    raw = crimson_rs.extract_file(
        args.game_path, "0008", "gamedata/binary__/client/bin", "skill.pabgb"
    )
    print(f"   skill.pabgb size: {len(raw):,} bytes")

    candidates = [args.skill_name] if args.skill_name else DEFAULT_SKILL_NAME_CANDIDATES
    name = None
    name_off = -1
    for cand in candidates:
        if cand is None:
            continue
        off = find_name_offset(raw, cand)
        if off >= 0:
            name = cand
            name_off = off
            break
    if name_off < 0:
        print(f"!! none of these skill name strings were found in skill.pabgb:")
        for c in candidates:
            print(f"     {c!r}")
        print("   Re-run with --skill-name '<exact_name>' once you know it.")
        return 2

    print(f"\n=> Found skill name {name!r} at offset 0x{name_off:X}")
    print(f"   Reading class list at name+0x{args.offset:X} (= 0x{name_off + args.offset:X})")

    try:
        count, hashes, list_pos = read_class_list(raw, name_off, args.offset)
    except (SystemExit, struct.error) as e:
        print(f"!! could not read list at +{args.offset}: {e}")
        if args.hexdump:
            print(hexdump(raw, name_off, 192))
        return 2

    print(f"   current count: {count}")
    print(f"   current hashes: {hashes}")

    if args.hexdump:
        print(f"\n--- HEXDUMP from list position 0x{list_pos:X} ---")
        print(hexdump(raw, list_pos, 64))

    if args.dry_run:
        print("\n[--dry-run] no file written.")
        return 0

    new_hashes = [h for h in args.add_hash if h not in hashes]
    if not new_hashes:
        print("\n   all requested hashes already present — nothing to do.")
        return 0

    print(f"\n=> Appending {new_hashes} -> new count {count + len(new_hashes)}")
    new_blob = patch_class_list(raw, list_pos, count, hashes, new_hashes)
    print(f"   new size: {len(new_blob):,} bytes (delta {len(new_blob) - len(raw):+d})")

    out_dir = Path(args.out).resolve()
    diff = {
        "name": name,
        "name_offset": name_off,
        "offset_from_name": args.offset,
        "before": {"count": count, "hashes": hashes},
        "after":  {"count": count + len(new_hashes), "hashes": hashes + new_hashes},
        "added_hashes": new_hashes,
    }
    write_mod_folder(out_dir, new_blob, args.mod_name, diff)
    print(f"\n=> Wrote mod folder: {out_dir}")
    print(f"   files/gamedata/binary__/client/bin/skill.pabgb ({len(new_blob):,} bytes)")
    print(f"   modinfo.json + patch_diff.json")

    print("\n=> Done. Install via your mod loader.")
    print("   If the lightning passive activates on the bow now, Potter's pattern works.")
    print("   If the game crashes on launch / load, skill.pabgb may need the original")
    print("   PAZ-checksum workaround (file-overlay loaders avoid this).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
