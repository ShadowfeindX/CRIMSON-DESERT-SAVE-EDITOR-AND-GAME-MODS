#!/usr/bin/env python3
"""
test_lightning_unlock.py — Approach A test for the lightning-imbue gimmick.

Hypothesis: docking_tag_name_hash[] on a wrapper item (e.g. 1001062
'Marni_MachineKnight_TwoHandSword') is OR'd by the engine — filling
extra slots with other weapon-class hashes makes the gimmick attach
to those classes too.

This script:
  1. Extracts iteminfo.pabgb from the live game install (via crimson_rs).
  2. Patches the wrapper item's docking_tag_name_hash slots.
  3. Re-serializes iteminfo.
  4. Writes a CDUMM-compatible mod folder with the patched file.

Drop the resulting folder into your CDUMM mods directory and load it
in-game. Equip a target weapon class — if the lightning VFX appears,
approach A works and the engine OR's slot 0..3.

Usage:
  python tools/test_lightning_unlock.py
  python tools/test_lightning_unlock.py --add-class 670734787 247236102
  python tools/test_lightning_unlock.py --wrapper 1001062 --out my_mod_dir

Class hashes (from iteminfo dump audit):
  3365725887 = TwoHandSword (already in slot 0 of 1001062)
   666382090 = TwoHandSpear
   670734787 = OneHandBow
  3332282737 = OneHandShield
  3097161937 = BackPack
  3941306321 = PlateArmor_Helm
  2875817978 = Cloak
  3926445710 = Lantern
   247236102 = Plate_Boots
  4052041933 = FlameThrower

Default behavior: adds OneHandBow (670734787) to slot 1, leaving slot 0
(TwoHandSword) intact.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
from pathlib import Path

import crimson_rs


DEFAULT_GAME_PATH = r"C:\Program Files (x86)\Steam\steamapps\common\Crimson Desert"
DEFAULT_WRAPPER_KEY = 1001062  # Marni_MachineKnight_TwoHandSword (lightning gimmick wrapper)
DEFAULT_HASHES_TO_ADD = [670734787]  # OneHandBow

KNOWN_CLASS_HASHES = {
    3365725887: "TwoHandSword",
    666382090:  "TwoHandSpear",
    670734787:  "OneHandBow",
    3332282737: "OneHandShield",
    3097161937: "BackPack",
    3941306321: "PlateArmor_Helm",
    2875817978: "Cloak",
    3926445710: "Lantern",
    247236102:  "Plate_Boots",
    4052041933: "FlameThrower",
}


def _hash_label(h: int) -> str:
    if h in (0, 0xFFFFFFFF):
        return "(empty)"
    return KNOWN_CLASS_HASHES.get(h, f"unknown:{h}")


def patch_wrapper(items: list, wrapper_key: int, add_hashes: list[int]) -> dict:
    """Patch one wrapper item's docking_tag_name_hash array."""
    target = next((it for it in items if it.get("key") == wrapper_key), None)
    if target is None:
        raise SystemExit(f"wrapper item key={wrapper_key} not found in iteminfo")

    dcd = target.get("docking_child_data")
    if not dcd:
        raise SystemExit(
            f"item {wrapper_key} has no docking_child_data — wrong wrapper?"
        )

    before = list(dcd.get("docking_tag_name_hash", [0, 0, 0, 0]))
    after = list(before)

    next_slot = next((i for i, v in enumerate(after) if v in (0, 0xFFFFFFFF)), None)
    if next_slot is None:
        raise SystemExit(f"all 4 docking_tag_name_hash slots full: {before}")

    for h in add_hashes:
        if next_slot is None or next_slot >= 4:
            print(f"WARN: ran out of slots, dropped extra hash {h}")
            break
        if h in after:
            print(f"  skip {h} ({_hash_label(h)}) — already present")
            continue
        after[next_slot] = h
        next_slot = next(
            (i for i in range(next_slot + 1, 4) if after[i] in (0, 0xFFFFFFFF)),
            None,
        )

    dcd["docking_tag_name_hash"] = after
    return {
        "wrapper_key": wrapper_key,
        "string_key": target.get("string_key"),
        "before": [(h, _hash_label(h)) for h in before],
        "after":  [(h, _hash_label(h)) for h in after],
    }


def write_mod_folder(out_dir: Path, iteminfo_bytes: bytes, mod_name: str) -> None:
    """Write a drop-in folder layout that CDUMM (or any PAZ overlay loader) accepts."""
    if out_dir.exists():
        import shutil
        shutil.rmtree(out_dir)
    files_dir = out_dir / "files" / "gamedata" / "binary__" / "client" / "bin"
    files_dir.mkdir(parents=True, exist_ok=True)

    pabgb_path = files_dir / "iteminfo.pabgb"
    pabgb_path.write_bytes(iteminfo_bytes)

    modinfo = {
        "id": mod_name.lower().replace(" ", "_"),
        "name": mod_name,
        "version": "0.1.0",
        "game_version": "1.00.03",
        "author": "test_lightning_unlock",
        "description": (
            "Adds extra docking_tag_name_hash slots to the lightning-imbue "
            "wrapper item so the gimmick may attach to additional weapon classes. "
            "TEST MOD — verify in-game whether the VFX attaches when the added "
            "weapon class is wielded."
        ),
    }
    (out_dir / "modinfo.json").write_text(
        json.dumps(modinfo, indent=2), encoding="utf-8"
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Approach-A patcher for lightning gimmick filter.")
    p.add_argument("--game-path", default=DEFAULT_GAME_PATH,
                   help="Crimson Desert install path (used when --input-iteminfo not given)")
    p.add_argument("--input-iteminfo", default=None,
                   help="path to an existing iteminfo.pabgb (e.g. inside another mod). "
                        "When given, the patch is layered on top of THIS file instead of "
                        "vanilla — preserves your existing iteminfo mod's changes.")
    p.add_argument("--wrapper", type=int, default=DEFAULT_WRAPPER_KEY,
                   help=f"wrapper item key (default {DEFAULT_WRAPPER_KEY})")
    p.add_argument("--add-class", type=int, nargs="+", default=DEFAULT_HASHES_TO_ADD,
                   help="class hashes to add into empty slots")
    p.add_argument("--out", default="lightning_unlock_test",
                   help="output mod folder name")
    p.add_argument("--mod-name", default="Lightning Imbue Unlock (Test)",
                   help="display name in modinfo.json")
    args = p.parse_args()

    if args.input_iteminfo:
        src_path = Path(args.input_iteminfo).resolve()
        if not src_path.is_file():
            raise SystemExit(f"--input-iteminfo path does not exist: {src_path}")
        print(f"=> Reading existing iteminfo from: {src_path}")
        raw = src_path.read_bytes()
        print(f"   iteminfo.pabgb size: {len(raw):,} bytes  (layered on top of your mod)")
    else:
        print(f"=> Extracting vanilla iteminfo from: {args.game_path}")
        raw = crimson_rs.extract_file(
            args.game_path, "0008", "gamedata/binary__/client/bin", "iteminfo.pabgb"
        )
        print(f"   iteminfo.pabgb size: {len(raw):,} bytes  (vanilla — will overwrite any other iteminfo mod)")

    items = crimson_rs.parse_iteminfo_from_bytes(raw)
    print(f"   parsed items: {len(items):,}")

    print(f"\n=> Patching wrapper item {args.wrapper} with hashes: "
          f"{[(h, _hash_label(h)) for h in args.add_class]}")
    diff = patch_wrapper(items, args.wrapper, args.add_class)
    print(f"   string_key: {diff['string_key']}")
    print(f"   BEFORE: {diff['before']}")
    print(f"   AFTER:  {diff['after']}")

    print("\n=> Re-serializing iteminfo...")
    new_bytes = bytes(crimson_rs.serialize_iteminfo(items))
    print(f"   new size: {len(new_bytes):,} bytes  (delta {len(new_bytes) - len(raw):+d})")

    out_dir = Path(args.out).resolve()
    print(f"\n=> Writing mod folder: {out_dir}")
    write_mod_folder(out_dir, new_bytes, args.mod_name)
    print(f"   wrote {out_dir / 'files' / 'gamedata' / 'binary__' / 'client' / 'bin' / 'iteminfo.pabgb'}")
    print(f"   wrote {out_dir / 'modinfo.json'}")

    print("\n=> Done.")
    print("   Install via your mod loader (CDUMM, DMM, JSON Mod Manager).")
    print(f"   Wrapper item {args.wrapper} ({diff['string_key']}) now has these")
    print(f"   docking slots: {diff['after']}")
    print()
    print("   Test in-game: equip the weapon class for any non-empty slot.")
    print("   If the lightning VFX attaches when the added class is wielded,")
    print("   approach A is confirmed and we can pack any combination.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
