#!/usr/bin/env python3
"""
pack_native_overlay.py — package one or more .pabgb edits into a native PAZ
overlay group at the game root (e.g. 0061/0.paz + 0.pamt). Loaded directly
by the game without any mod loader. Higher-numbered groups override lower
ones, so this beats other PAZ overlays sitting at the same path.

Usage:
  python tools/pack_native_overlay.py \\
      --group 0061 \\
      --add bow_passive_iteminfo/files/gamedata/binary__/client/bin/iteminfo.pabgb \\
      --add bow_skill_unlock/files/gamedata/binary__/client/bin/skill.pabgb

  # or:
  python tools/pack_native_overlay.py \\
      --group 0061 \\
      --add iteminfo.pabgb \\
      --add skill.pabgb
"""
from __future__ import annotations
import argparse
import os
import sys
from pathlib import Path

import crimson_rs


DEFAULT_GAME_PATH = r"C:\Program Files (x86)\Steam\steamapps\common\Crimson Desert"
DEFAULT_INTERNAL_DIR = "gamedata/binary__/client/bin"


def main() -> int:
    p = argparse.ArgumentParser(description="Package .pabgb edits as a native PAZ overlay group.")
    p.add_argument("--game-path", default=DEFAULT_GAME_PATH)
    p.add_argument("--group", required=True, help="4-digit overlay group number, e.g. 0061")
    p.add_argument("--add", action="append", required=True,
                   help="path to a modified .pabgb file (repeatable). Filename is preserved.")
    p.add_argument("--internal-dir", default=DEFAULT_INTERNAL_DIR,
                   help=f"internal PAZ directory (default '{DEFAULT_INTERNAL_DIR}')")
    p.add_argument("--out-root", default=None,
                   help="where to write the group folder (default = game root). "
                        "Use a temp dir when you want to inspect before installing.")
    args = p.parse_args()

    if not (len(args.group) == 4 and args.group.isdigit()):
        raise SystemExit(f"--group must be 4 digits, got {args.group!r}")

    out_root = Path(args.out_root) if args.out_root else Path(args.game_path)
    group_dir = out_root / args.group

    if group_dir.exists():
        ans = input(f"{group_dir} exists — overwrite? [y/N] ").strip().lower()
        if ans != "y":
            print("aborted.")
            return 1
        import shutil
        shutil.rmtree(group_dir)
    group_dir.mkdir(parents=True)

    print(f"=> Building PAZ group {args.group} at: {group_dir}")
    builder = crimson_rs.PackGroupBuilder(
        str(group_dir),
        crimson_rs.Compression.LZ4,
        crimson_rs.Crypto.NONE,
    )

    for src in args.add:
        src_path = Path(src).resolve()
        if not src_path.is_file():
            raise SystemExit(f"--add path not found: {src_path}")
        data = src_path.read_bytes()
        print(f"   add file  {args.internal_dir}/{src_path.name}  ({len(data):,} bytes)")
        builder.add_file(args.internal_dir, src_path.name, data)

    pamt_bytes = builder.finish()
    print(f"   wrote 0.paz + 0.pamt ({len(pamt_bytes):,} bytes pamt)")

    print(f"\n=> Done. Native overlay live at {group_dir}")
    print(f"   The game will load it on launch (group {args.group} > any lower group).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
